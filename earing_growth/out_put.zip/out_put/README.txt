The name "earingdiff1y_div_bet-r_winsor0_ffill_rp__Unv_-1__Idx_avg" can be interpreted as follows:
"earingdiff1y": Represents the difference between earnings at time t and earnings one year ago.
"div_bet-r": Indicates that the earnings are divided by the book equity at time t minus r.
"winsor0": Implies that only financial data published within specific time periods are selected. For instance, annual financial reports are disclosed between January 1st and April 30th each year, semi-annual reports between July 1st and August 30th, and quarterly reports during specific periods (e.g., April 1st to April 30th for the first quarter, and October 1st to October 31st for the third quarter).
"ffill_rp": Denotes that only trading days during financial reporting periods are filled. Alternatively, "fill_unv" would signify filling data for all trading days throughout the year.
 "Unv_-1_Idx_avg": Indicates that the reference return is the average market return.
Other namings can refer to this explanation.
